const restrictedUsers = [

    { id: "228671235519676417", username: "Hasta: **Para siempre** (GMT+9:30) By [Anti-Cheating Mylen](https://mylen.xyz/anticheating)" },
];

module.exports = restrictedUsers;